import { combineReducers } from 'redux';
import sessionReducer from './session_reducer';

const LaWebApp = combineReducers({
  sessionReducer
})

export default LaWebApp