
export default function setSession(name) {
    return {
        type: "SET_SESSION",
        name: name
    };
}
